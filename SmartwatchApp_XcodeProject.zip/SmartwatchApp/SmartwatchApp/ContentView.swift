
import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, SmartwatchApp!")
            .padding()
    }
}

#Preview {
    ContentView()
}
