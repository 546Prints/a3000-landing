import SwiftUI
@main
struct SmartwatchApp: App { var body: some Scene { WindowGroup { ContentView() } } }